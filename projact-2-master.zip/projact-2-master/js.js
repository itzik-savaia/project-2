var timearr = [];//time local 
var arr = [];//local storag
var CoinName;//coin name

//ajax 5 coin//
var arrCoin = [];//coins checked
var ajaxarr = []
var coin5arr = ["ETH", "DASH", "USD", "ZRX", "ZCN"];//ajax to $
//ajax 5 coin//

$(document).ready(function () {
  $("#about").click(function () {
    $(".text-center").fadeIn(1200);
    $(".text-center").html(`
            <h1>פרוייקט-2</h1>
            <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
            <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
            <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
            <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
            <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
            <h3>איציק סביה
                תז-311320311
            </h3>
            <h6>api.coingecko.com-פרוייקט דיווח מצב בטבעות לפי זמן נתון דרך אתר</h6>
        </div>
        `);
  });

  ////////////////All-Coins////////////////
  $("#coin").click(function () {
    $(".text-center").html(`
    <h1 class="col-sm-12">מטבעות</h1>
    <div class="col-sm-12">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    </div>`);
    $.ajax({
      type: "GET",
      url: `https://api.coingecko.com/api/v3/coins/list`,
      async: false,
      success: function (data) {
        for (var num = 0, newdata = 50; num <= newdata; num++) {
          var numberCard = num;
          $(".text-center").append(`
          <div>
              <div class="card col-lg-3 col-md-6 col-sm-12 float-left" id="${num}">
                <div class="card-body">
                <h2 class="card-title"id="NameCoin">${data[num].name}</h2>
                <h5 class="card-title" id="CoinId">${data[num].id}</h5>
                <!-- radio -->
                  <div>
                  <label class="toggle-event" id="toggle${num}">
                  <input type="checkbox">
                  <span class="slider round"></span>
                  </label>
                  </div>
                  <!-- radio -->
                <h5 class="card-text" id="symbol">Symbol :  ${data[num].symbol}</h5>
                  <div class="row, justify-content-center">
                  <div id="demo${num}" class="collapse in"><div class="loader"></div></div>
                    <button type="button" class="btn btn-info collapsed" data-toggle="collapse" data-target="#demo${num}"></button>
                  </div>
                  </div>  
                </div>
          </div>`);
          ////////////////All-Coins//////////////// 
        }
      }
    })
  });

  $("body").on("click", ".collapsed", function () {
    CoinName = $(this)
      .parent()
      .parent()
      .find("#CoinId")
      .html();
    var collapsed = $(this).hasClass(".collapsed");
    var dataid = $(this).attr("data-target");

    ////////////////time////////////////
    var newDate = new Date();
    var timenow = newDate.getTime();
    console.log("time-now", timenow);
    ////////////////time////////////////

    ////////////////AJAX-Coins///////////////
    if (!collapsed) {
      if (timearr[dataid] == null || timenow > timearr[dataid]) {
        $.ajax({
          type: "GET",
          url: `https://api.coingecko.com/api/v3/coins/` + CoinName,
          success: function (response) {
            $("body").find(`${dataid}`).html(`
                  <div class="row, justify-content-center" >
                          <h6>
                          <div><img src="${response.image.small}"></div>
                              USD : ${response.market_data.current_price.usd} $  </br>
                              EUR : ${response.market_data.current_price.eur} €  </br>
                              ILS : ${response.market_data.current_price.ils} ₪  </br>
                          </h6>
                  </div>
              </div>
          </div>
          `); ////////////////AJAX-Coins///////////////

            ////////////////time-clike////////////////
            timeClike = newDate.getTime() + 120000; //time on clike to local
            timearr[dataid] = timeClike;
            console.log("timearr", timearr);
            console.log("timeClike", timeClike);
            ////////////////time-clike////////////////

            ////////////////local-storage////////////////
            if (typeof Storage !== "undefined") {
              arr = JSON.parse(localStorage.getItem("objCoin")) || [];
              objCoin = {};
              objCoin.TIMECLIKE = timeClike;
              objCoin.USD = response.market_data.current_price.usd;
              objCoin.EUR = response.market_data.current_price.eur;
              objCoin.ILS = response.market_data.current_price.ils;
              objCoin.IMG = response.image.small;
              if (arr.length == CoinName) {
                arr.slice(objCoin);
              } else {
                arr.push(objCoin);
              }
              localStorage.setItem("objCoin", JSON.stringify(arr));
              console.log("arr.localstorage", arr);
            }
          }
          ////////////////local-storage////////////////
        });
      }
    }
  });

  ////////////////check-toggle////////////////
  $("body").on("click", ".toggle-event", function () {
    var thisSymbol = $(this).parent().parent().find('#symbol').html();
    var thisCoin = this.id;
    var checked = this.firstElementChild.checked;
    if (checked) {
      if (arrCoin.length > 4) {
        $("#myModal").modal();
        console.log(arrCoin);
        checked == true
      } else {
        arrCoin.push(thisSymbol);
        console.log(arrCoin);
        $(".modal-body").append(`
        <input type="checkbox" class="form-check-input" id=${checked} checked>
        <span class="modalspan">${checked}</span><br></div>
        `);
      }
    } else {
      for (var num = 0; num < arrCoin.length; num++) {
        console.log(this.id, "checked", + num);
        if (arrCoin[num] === thisSymbol) {
          arrCoin.splice(num, 1);
          $(".modal-body").find("#" + `${thisSymbol}`).remove();
          console.log($(".modal-body"));
        }
      }
    }
    ////////////////modal////////////////
    $(".modal-body").on("change", ".toggle-event", function () {
      console.log(thisCoin);
      $("body").find("#" + thisCoin === !checked);
      console.log("#" + thisCoin === !checked);
      for (var num = 0; num < arrCoin.length; num++) {
        if (arrCoin[i] == thisCoin) {
          arrCoin.splice(num, 1);
          console.log(arrCoin);
          $(this).parent().hide();
        }
      }

    });////////////////modal////////////////

  }); /////<---end click toggle/////



  ///////////////////////////////////////////
  ///////////////canvas-js/////////////////
  ///////////////////////////////////////////
  $("#reports").click(function () {
    ////////////////AJAX-Coins///////////////
    function ajax() {
      $.ajax({
        url:
          "https://min-api.cryptocompare.com/data/pricemulti?fsyms=" + arrCoin + "&tsyms=USD",
        success: function (result) {
          for (let index = 0; index < 5; index++) {
            if (result[arrCoin[index]] == undefined) {
              ajaxarr[index] = "no data";
              options.data[index].name = "no data";
              ajaxarr[index] = 0;
            }
            else {
              ajaxarr[index] = arrCoin[index];
              options.data[index].name = arrCoin[index];
              ajaxarr[index] = result[arrCoin[index]].USD;
            }
          }
          console.log("ajaxarr", ajaxarr);
          console.log("data", options.data);

        },
      });
    } ////////////////AJAX-Coins///////////////
    $(".text-center").html(`
    <h1>דוחות בזמן אמת</h1>
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    <img src="/img/Bitcoin animation.gif" alt="מטבעה"  class="animationbit">
    `);
    var dataPoints1 = [];
    var dataPoints2 = [];
    var dataPoints3 = [];
    var dataPoints4 = [];
    var dataPoints5 = [];
    var options = {};
    intervel = setInterval(ajax, 2000);
    options = {
      title: {
        text: "Electricity Generation in Turbine"
      },
      axisX: {
        title: "chart updates every 2 secs"
      },
      axisY: {
        suffix: "Wh",
        includeZero: false
      },
      toolTip: {
        shared: true
      },
      legend: {
        cursor: "pointer",
        verticalAlign: "top",
        fontSize: 22,
        fontColor: "dimGrey",
        itemclick: toggleDataSeries
      },
      data: [{
        type: "line",
        xValueType: "dateTime",
        yValueFormatString: "###.00Wh",
        xValueFormatString: "hh:mm:ss TT",
        showInLegend: true,
        name: ajaxarr[0],
        dataPoints: dataPoints1
      },
      {
        type: "line",
        xValueType: "dateTime",
        yValueFormatString: "###.00Wh",
        showInLegend: true,
        name: ajaxarr[1],
        dataPoints: dataPoints2
      },
      {
        type: "line",
        xValueType: "dateTime",
        yValueFormatString: "###.00Wh",
        showInLegend: true,
        name: ajaxarr[2],
        dataPoints: dataPoints3
      },
      {
        type: "line",
        xValueType: "dateTime",
        yValueFormatString: "###.00Wh",
        showInLegend: true,
        name: ajaxarr[3],
        dataPoints: dataPoints4
      },
      {
        type: "line",
        xValueType: "dateTime",
        yValueFormatString: "###.00Wh",
        showInLegend: true,
        name: ajaxarr[4],
        dataPoints: dataPoints5
      }
      ]
    };
    var chart = $("#chartContainer").CanvasJSChart(options);

    function toggleDataSeries(e) {
      if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
        e.dataSeries.visible = false;
      }
      else {
        e.dataSeries.visible = true;
      }
      e.chart.render();
    }

    var updateInterval = 2000;
    // initial value
    var yValue1 = ajaxarr[0];
    var yValue2 = ajaxarr[1];
    var yValue3 = ajaxarr[2];
    var yValue4 = ajaxarr[3];
    var yValue5 = ajaxarr[4];

    var time = new Date;
    // starting at 10.00 am
    time.getHours();
    time.getMinutes();
    time.getSeconds();
    time.getMilliseconds();

    function updateChart(count) {
      count = count || 1;
      for (var i = 0; i < count; i++) {
        time.setTime(time.getTime() + updateInterval);


        yValue1 = ajaxarr[0];
        yValue2 = ajaxarr[1];
        yValue3 = ajaxarr[2];
        yValue4 = ajaxarr[3];
        yValue5 = ajaxarr[4];

        dataPoints1.push({
          x: time.getTime(),
          y: yValue1
        });
        dataPoints2.push({
          x: time.getTime(),
          y: yValue2
        });
        dataPoints3.push({
          x: time.getTime(),
          y: yValue3
        });
        dataPoints4.push({
          x: time.getTime(),
          y: yValue4
        });
        dataPoints5.push({
          x: time.getTime(),
          y: yValue5
        });
      }
      if (ajaxarr == null && undefined) {
        alert("no data")
      }
      options.data[0].legendText = ajaxarr[0] + yValue1 + "$";
      options.data[1].legendText = ajaxarr[1] + yValue2 + "$";
      options.data[2].legendText = ajaxarr[2] + yValue3 + "$";
      options.data[3].legendText = ajaxarr[3] + yValue4 + "$";
      options.data[4].legendText = ajaxarr[4] + yValue5 + "$";
      $("#chartContainer").CanvasJSChart().render();
    }
    // generates first set of dataPoints 
    updateChart(1);
    setInterval(function () { updateChart() }, updateInterval);



  });
  ///////////////////////////////////////////
  ///////////////canvas-js/////////////////
  ///////////////////////////////////////////



});

